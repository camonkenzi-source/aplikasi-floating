package com.ziimodsx.assistant

import android.graphics.BitmapFactory
import android.graphics.Rect
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.nl.translate.*
import java.io.File

class ResultActivity : AppCompatActivity() {
    private lateinit var preview: ImageView
    private lateinit var output: TextView
    private lateinit var source: BitmapFactory.Options
    private var imagePath = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        imagePath = intent.getStringExtra("imagePath") ?: ""
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(16,16,16,16) }
        preview = ImageView(this).apply { adjustViewBounds=true; setImageBitmap(BitmapFactory.decodeFile(imagePath)) }
        root.addView(preview, LinearLayout.LayoutParams(-1,0,1f))
        output = TextView(this).apply { text="Pilih tindakan"; textSize=16f }
        root.addView(output)
        root.addView(Button(this).apply { text="Baca teks layar"; setOnClickListener { readText() } })
        root.addView(Button(this).apply { text="Translate ke Indonesia"; setOnClickListener { translateText() } })
        root.addView(Button(this).apply { text="Tutup"; setOnClickListener { finish() } })
        setContentView(root)
    }
    private fun readText(onDone: ((String)->Unit)? = null) {
        val bitmap=BitmapFactory.decodeFile(imagePath)
        if(bitmap==null){ output.text="Gambar layar tidak tersedia"; return }
        val recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        recognizer.process(InputImage.fromBitmap(bitmap,0))
            .addOnSuccessListener { result ->
                val text=result.text.ifBlank { "Tidak ada teks yang terdeteksi." }
                output.text=text
                onDone?.invoke(text)
            }.addOnFailureListener { output.text="OCR gagal: ${it.localizedMessage}" }
    }
    private fun translateText() {
        readText { text ->
            val options=TranslatorOptions.Builder().setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.INDONESIAN).build()
            val translator=Translation.getClient(options)
            translator.downloadModelIfNeeded()
                .addOnSuccessListener {
                    translator.translate(text).addOnSuccessListener { output.text=it }
                        .addOnFailureListener { output.text="Terjemahan gagal: ${it.localizedMessage}" }
                }.addOnFailureListener { output.text="Gagal mengunduh model bahasa. Cek internet." }
        }
    }
}
