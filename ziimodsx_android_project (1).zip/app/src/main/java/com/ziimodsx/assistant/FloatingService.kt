package com.ziimodsx.assistant

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.*
import android.widget.Button
import android.widget.FrameLayout
import android.widget.Toast
import androidx.core.app.NotificationCompat
import java.io.File
import java.io.FileOutputStream

class FloatingService : Service() {
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var bubble: View? = null
    private var windowManager: WindowManager? = null
    private var screenW = 0
    private var screenH = 0
    private var density = 1

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotification()
        val resultCode = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED) ?: return START_NOT_STICKY
        val data = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra("projectionData", Intent::class.java) else @Suppress("DEPRECATION") intent.getParcelableExtra("projectionData")
        if (data != null && projection == null) startProjection(resultCode, data)
        showBubble()
        return START_STICKY
    }

    private fun createNotification() {
        val channelId = "ziimodsx_capture"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "ziimodsx screen capture", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("ziimodsx aktif")
            .setContentText("Tekan gelembung untuk memilih area layar")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setOngoing(true).build()
        startForeground(7, notification)
    }

    private fun startProjection(code: Int, data: Intent) {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION") (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        screenW = metrics.widthPixels; screenH = metrics.heightPixels; density = metrics.densityDpi
        reader = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 2)
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(code, data)
        virtualDisplay = projection?.createVirtualDisplay("ziimodsx-display", screenW, screenH, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, null)
    }

    private fun showBubble() {
        if (bubble != null) return
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val button = Button(this).apply {
            text = "AI"
            textSize = 14f
            setOnClickListener { captureAndOpen() }
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(62, 62, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = 12; y = 260
        }
        button.setOnTouchListener(object : View.OnTouchListener {
            var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { downX=e.rawX; downY=e.rawY; startX=params.x; startY=params.y; moved=false; return true }
                    MotionEvent.ACTION_MOVE -> {
                        val dx=(e.rawX-downX).toInt(); val dy=(e.rawY-downY).toInt()
                        if (kotlin.math.abs(dx)>8 || kotlin.math.abs(dy)>8) moved=true
                        params.x=startX+dx; params.y=startY+dy
                        windowManager?.updateViewLayout(button, params); return true
                    }
                    MotionEvent.ACTION_UP -> { if (!moved) captureAndOpen(); return true }
                }
                return false
            }
        })
        windowManager?.addView(button, params); bubble = button
    }

    private fun captureAndOpen() {
        val image = reader?.acquireLatestImage()
        if (image == null) { Toast.makeText(this, "Belum ada frame layar. Coba lagi.", Toast.LENGTH_SHORT).show(); return }
        try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * screenW
            val bitmap = Bitmap.createBitmap(screenW + rowPadding / pixelStride, screenH, Bitmap.Config.ARGB_8888)
            bitmap.copyPixelsFromBuffer(buffer)
            val cropped = Bitmap.createBitmap(bitmap, 0, 0, screenW, screenH)
            val file = File(cacheDir, "screen_capture.png")
            FileOutputStream(file).use { cropped.compress(Bitmap.CompressFormat.PNG, 100, it) }
            val open = Intent(this, ResultActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                putExtra("imagePath", file.absolutePath)
            }
            startActivity(open)
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal mengambil layar: ${e.message}", Toast.LENGTH_LONG).show()
        } finally { image.close() }
    }

    override fun onDestroy() {
        bubble?.let { try { windowManager?.removeView(it) } catch (_: Exception) {} }
        virtualDisplay?.release(); reader?.close(); projection?.stop()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
