# ziimodsx Android starter

Android native floating assistant prototype.

## Features in this starter
- Floating overlay button (requires "Display over other apps" permission).
- User-consented MediaProjection screen capture.
- OCR text recognition using ML Kit.
- Translate recognized English text to Indonesian using ML Kit translation.

## Build APK using GitHub on Android
1. Create a GitHub repository named `ziimodsx`.
2. Upload all files/folders from this project to the repository root.
3. Open Actions tab and run **Build ziimodsx APK** (or push to `main`).
4. Wait for workflow to finish successfully.
5. Open the workflow run, download artifact `ziimodsx-debug-apk`, extract it, and install `app-debug.apk`.

## Notes
- This is a starter project, not a published production app.
- The current selection workflow captures the screen then shows OCR/translation actions; precise draggable circle/crop selection and AI answer backend are not yet implemented.
- AI answer requires a secure backend endpoint; never put an API secret in the APK or a public GitHub repository.
- Screen capture is user-consented and indicated by Android's screen-capture notification.
